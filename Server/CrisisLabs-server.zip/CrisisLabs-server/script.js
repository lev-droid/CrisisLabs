const express = require('express');
const cors = require('cors');
const udp = require("dgram");

const app = express();
app.use(cors());

// data backlog, used because the site has to send a request to the server rather than listening to a live feed
var data = [];

const detrendLimit = 50; // How many data points to consider when detrending.
var detrendTable = [];
detrendTable["'EHZ'0"] = [];
detrendTable["'ENZ'0"] = []; 
detrendTable["'ENN'0"] = []; 
detrendTable["'ENE'0"] = []; 
detrendTable["'EHZ'1"] = [];
detrendTable["'ENZ'1"] = []; 
detrendTable["'ENN'1"] = []; 
detrendTable["'ENE'1"] = []; 

var detrendTime = 0;

//const rounding = Math.pow(10, 10);

var conversion = [];
conversion["'EHZ'"] = 39965000;
conversion["'ENZ'"] = 384500; 
conversion["'ENN'"] = 384500; 
conversion["'ENE'"] = 384500; 

function GetAverage(array)
{
	var avg = 0;
	for (var i = 0; i < array.length; i++)
	{
		avg += array[i];
	}
	return (avg / array.length);
}

function ConvertData(input, shake)
{
	// NOTE: REMEMBER TO PUT A SANITY CHECK BEFORE PARSING DATA INTO THIS FUNCTION
	
	// I know I said I was going to un-spaghetti Brendan's code, but at least to some extent, it was programmed the way it was due to the formatting of the input data. Though this is better, it's still not really all that great.
	var output = "";
	var inputArr = input.replace('}', '').replace('{', '').split(',');
	
	// The first index is a string (the seismograph this data came from), the second is a float, and the rest are all ints. We need to convert them all to their respective types.
	// I could do this more expandably, but it'd come at the cost of a heavy hit to efficiency, so I'll leave it for now.
	var station = inputArr[0];
	var station2 = station + shake;
	var time = parseFloat(inputArr[1]);
	var cData = [];
	for (var i = 2; i < inputArr.length; i++)
	{
		cData[i-2] = parseInt(inputArr[i]);
	}
	
	// Now that the data has been properly organized, we need to process it - detrend it, convert it to m/s, etc.
	
	// Check if a default time value has been set - if not, set one.
	if (detrendTime == 0)
	{
		detrendTime = time;
	}
	time -= detrendTime;

	// Calculate the average of recent data.
	var avg = 0;
	if (detrendTable.length < 1)
	{
		avg = cData[0];
	} else {
		avg = GetAverage(detrendTable[station2]);
	}
	
	// Subtract said average from the data that is currently being processed, update the arrays used for the previous step, and convert the data into a format which the website can read.
	for (var i = 0; i < cData.length; i++)
	{
		//cData[i] -= avg;
		detrendTable[station2].splice(0, 0, cData[i]/detrendLimit);
		
		//cData[i] = cData[i]/conversion[station].toFixed(10);
		//cData[i] = Math.floor((cData[i]/conversion[station]) * rounding)/rounding; // Convert data from counts to m/s^2 and round it to a reasonable number of decimals.
		
		//output += '~' + station + ',' + time + ',' + cData[i];
		
		detrendTable[station2].splice(-1, 1); // cant merge the splice lines because old data needs to be removed before new
	}
	//delimitTable[station].length = delimitLimit // if this line doesnt work in js, delete it and uncomment last line of loop
	//console.log(GetAverage(cData) + " - " + avg + " / " + conversion[station] + "\n");
	output += "~" + station2 + "," + time + "," + ((GetAverage(cData) - avg)/conversion[station].toFixed(10));

	console.log(output + "\n-----------\n");
	
	return (output);
}

function RecieveData(msg, info, shake)
{
	//console.log(msg.toString());
	if (data.length > 100000) 
	{
		data = [];
	}
	
	if (msg != null) // NOTE: FLESH OUT THIS SANITY CHECK - STILL VULNERABLE TO EXTERNAL INTERFERENCE (i.e. if something sends data to this device over a port the shake uses, it will die)
	{
		data.push(ConvertData(msg.toString(), 0) + "|" + data.length + "|");
	}
};

app.get('/', (req,res)=>{
	var nData = data.slice();
	nData.splice(0, parseInt(req.header("id")));

	var response = "";
	for (var i = 0; i < nData.length; i++)
	{
		response += nData[i];
	}

	res.send(response);
});

app.listen(4000, ()=>{
	console.log("Server running on port 4000");
});


var server = udp.createSocket('udp4');
server.on("message", function(msg, info) {
	RecieveData(msg, info, 0);
});
server.on("listening", function() {
	console.log("Server listening to port 8888");
});
server.bind(8888);

var server2 = udp.createSocket('udp4');
server2.on("message", function(msg, info) {
	RecieveData(msg, info, 1);
});
server2.on("listening", function() {
	console.log("Server listening to port 8889");
});
server.bind(8889);